from pages.locators import CheckoutPageLocators, RegisterPageLoc
from common.waits import DriverWaits
import time
from selenium.webdriver.support.select import Select


class CheckoutPage(object):

    def __init__(self, driver):
        self.driver = driver
        self.driver_waits = DriverWaits(self.driver)

    def billing_address(self):

        self.driver.find_element(*CheckoutPageLocators.CHECK_BOX).click()
        self.driver.find_element(*CheckoutPageLocators.ITEMS_LIST).click()
        self.driver.find_element(*CheckoutPageLocators.GO_TO_CART_BUTTON).click()
        self.driver.find_element(*CheckoutPageLocators.PROCEED_TO_CHECKOUT_BTN).click()
        time.sleep(2)

        self.driver.find_element(*CheckoutPageLocators.CITY_TXT_BOX).send_keys('Dhaka')
        self.driver.find_element(*CheckoutPageLocators.ADD_1_TXT_BOX).send_keys('Mohammadpur')
        self.driver.find_element(*CheckoutPageLocators.ADD_2_TXT_BOX).send_keys('Adabor')
        self.driver.find_element(*CheckoutPageLocators.ZIP_CODE_TXT_BOX).send_keys('1207')

    def select_country_dropdown(self):

        country_dropdown = self.driver.find_element(*CheckoutPageLocators.COUNTRY_DROPDOWN)
        country_drop_down = Select(country_dropdown)
        country_drop_down.select_by_value('Bangladesh')
        time.sleep(2)

        state_dropdown = self.driver.find_element(*CheckoutPageLocators.STATE)
        state_province = Select(state_dropdown)
        state_province.select_by_visible_text('Other (Non US)')

    def checkout_confirmation(self):

        self.driver.find_element(*CheckoutPageLocators.CONTINUE_BTN).click()

        self.driver_waits.wait_till_element_is_visible(CheckoutPageLocators.CONTINUE_BTN_PAYMENT_METH)

        self.driver.find_element(*CheckoutPageLocators.CONTINUE_BTN_PAYMENT_METH).click()
        self.driver.find_element(*CheckoutPageLocators.CONTINUE_BTN_PAYMENT_INFO).click()
        self.driver.find_element(*CheckoutPageLocators.CONTINUE_BTN_CONFIRM_ORDER).click()
        time.sleep(3)

        self.driver.find_element(*CheckoutPageLocators.CONTINUE_THANK_YOU_PAGE).click()










    # def _is_active_payment_method(self, element):
    #     element_class = element.get_attribute('class')
    #     return 'is-active' in element_class

    # def get_info_from_checkout_page(self):
    #
    #     data = {
    #         'order_summary': {
    #             'title': self.driver.find_element(*CheckoutPageLocators.COURSE_TITLE).text,
    #             'price': self.driver.find_element(*CheckoutPageLocators.COURSE_PRICE).text,
    #         },
    #         'account_info': {
    #             'user_email': self.driver.find_element(*CheckoutPageLocators.USER_EMAIL).text,
    #         },
    #         'payment_methods': {
    #             'no_of_methods': len(self.driver.find_elements(*CheckoutPageLocators.PAYMENT_OPTION_TABS)),
    #             'methods': {
    #                 'credit_card': {
    #                     'is_active': self._is_active_payment_method(
    #                         self.driver.find_element(*CheckoutPageLocators.CREDIT_CARD_TAB)),
    #                     'label': self.driver.find_element(*CheckoutPageLocators.CREDIT_CARD_LABEL).text
    #                 },
    #                 'paypal': {
    #                     'is_active': self._is_active_payment_method(
    #                         self.driver.find_element(*CheckoutPageLocators.PAYPAL_TAB)),
    #                     'label': self.driver.find_element(*CheckoutPageLocators.PAYPAL_LABEL).text
    #                 },
    #             },
    #         },
    #     }
    #
    #     return data
