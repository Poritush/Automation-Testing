import time
from pages.locators import MainNavLocators, RegisterPageLoc, LoginPageLocators
from common.waits import DriverWaits


class MainNavigation(object):

    def __init__(self, driver):
        self.driver = driver
        self.driver_waits = DriverWaits(self.driver)


    def logout(self):

        self.driver.find_element(*RegisterPageLoc.MY_ACCOUNT_LINK)
        time.sleep(2)

        self.driver.find_element(*MainNavLocators.LOGOUT_LINK).click()
        self.driver_waits.wait_till_element_is_visible(LoginPageLocators.LOGIN_LINK)