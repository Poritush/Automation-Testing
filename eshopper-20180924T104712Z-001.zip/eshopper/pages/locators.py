from selenium.webdriver.common.by import By

class HomePageLocators(object):

    LOGO = (By.CLASS_NAME, 'header-logo')
    HOME_PAGE = (By.PARTIAL_LINK_TEXT, 'Home page')
    NEW_PRODUCTS = (By.PARTIAL_LINK_TEXT, 'New products')
    SEARCH_LINK = (By.XPATH, '/html/body/div[9]/div[1]/div[2]/div/div[2]/div/ul/li[10]/a')
    SEARCH_BOX = (By.ID, 'small-searchterms')
    SEARCH_ICON = (By.XPATH, '//*[@id="small-search-box-form"]/input[2]')
    CONTACT_US = (By.XPATH, '/html/body/div[9]/div[1]/div[2]/div/div[2]/div/ul/li[11]/a')
    SEARCH_RESULT_TEXT = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div[2]')

class AllCatagoriesMenu(object):

    COTTON_SAREE = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[1]/a')
    COTTON_SAREE_ATR_CLK = (By.XPATH, '/html/body/div[9]/div[4]/div[6]/div[2]/div[1]/h1')
    GAS_SILK_SAREE = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[2]/a')
    HALF_SILK_SAREE = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[3]/a')
    MOSLIN_JAMDANI_SAREE = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[4]/a')
    KATAN_SAREE = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[5]/a')
    PURE_SILK_SAREE = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[6]/a')
    INDIAN_SALWAR_KAMIZ = (By.XPATH, '/html/body/div[9]/div[2]/div/div[1]/div[1]/ul/li[7]/a')

class Wishlist(object):

    WISHLIST_ICON = (By.CLASS_NAME, 'cart-trigger')


class BuyNowPage(object):

    BUY_NOW_BTN = (By.XPATH, '/html/body/div[9]/div[4]/div[6]/div[1]/div/div[2]/div[1]/div[2]/div[1]/div/div[2]/div[3]/div[4]/div/button/span')
    GO_TO_CART_POPUP = (By.XPATH, '/html/body/div[13]/div[2]/div[3]/div/input')
    CONTINUE_SHOPPING_BTN = (By.PARTIAL_LINK_TEXT, 'continueshopping')
    BUY_NOW_CONT_BTN = (By.XPATH, '/html/body/div[9]/div[4]/div[6]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div[2]/div[3]/div[4]/div/button/span')
    PRICE_1 = (By.XPATH, '//*[@id="shopping-cart-form"]/div[1]/table/tbody/tr[1]/td[6]/span')
    QUANTITY_1 = (By.XPATH, '//*[@id="shopping-cart-form"]/div[1]/table/tbody/tr[1]/td[7]/input')
    TOTAL_1 = (By.XPATH, '//*[@id="shopping-cart-form"]/div[1]/table/tbody/tr[1]/td[8]/span')
    PROCEED_TO_CHECKOUT_BTN = (By.XPATH, '//*[@id="checkout"]')
    CONTINUE_BTN_BILLING_ADDRESS_PAGE = (By.ID, 'billing-buttons-container')
    CONTINUE__BTN_CHECKOUT_PAGE = (By.ID, 'shipping-buttons-container')
    CONTINUE_BTN_PAYMENT_INFO = (By.ID, 'payment-info-please-wait')
    CONTINUE_BTN_CONFIRM_ORDER_PAGE = (By.ID, 'confirm-order-please-wait')

class RegisterPageLoc(object):

    MY_ACCOUNT_LINK = (By.XPATH, '/html/body/div[9]/div[1]/div[1]/div/div[3]/label')
    REGISTER_LINK = (By.CLASS_NAME, 'ico-register')
    GENDER_CHECKBOX = (By.ID, 'gender-male')
    FIRST_NAME_TXT_BOX = (By.ID, 'FirstName')
    LAST_NAME_TXT_BOX = (By.ID, 'LastName')
    DOB_DD = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/div[1]/div[2]/form/div[1]/div[2]/div[4]/div/select[1]')
    DOB_MM = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/div[1]/div[2]/form/div[1]/div[2]/div[4]/div/select[2]')
    DOB_YYYY = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/div[1]/div[2]/form/div[1]/div[2]/div[4]/div/select[3]')
    EMAIL_TXT_BOX = (By.XPATH, '//*[@id="Email"]')
    PHONE_TXT_BOX = (By.XPATH, '//*[@id="Phone"]')
    NEWSLETTER_RADIO_BTN = (By.XPATH, '//*[@id="Newsletter"]')
    PASSWORD_TXT_BOX = (By.XPATH, '//*[@id="Password"]')
    CONFIRM_PASSWORD_TXT_BOX = (By.ID, 'ConfirmPassword')
    REGISTER_BTN = (By.ID, 'register-button')
    REGISTER_CONFIRM = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/form/div/div[2]/div[1]')

class AddToCartPage(object):

    ADD_TO_LIST_BTN = (By.ID, 'add-to-wishlist-button-submit')

class LoginPageLocators(object):

    LOGIN_LINK = (By.CLASS_NAME, 'ico-login')
    EMAIL_INPUT = (By.XPATH, '//*[@id="Email"]')
    PASSWORD_INPUT = (By.XPATH, '//*[@id="Password"]')
    LOGIN_BUTTON = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/div/div[2]/div[1]/div[2]/form/div[2]/div[2]/input')

class CheckoutPageLocators(object):

    CHECK_BOX = (By.ID, 'ShipToSameAddress')
    ITEMS_LIST = (By.CLASS_NAME, 'flyout-cart-wrapper')
    GO_TO_CART_BUTTON = (By.XPATH, '//*[@id="flyout-cart"]/div/div/div[4]/input')
    PROCEED_TO_CHECKOUT_BTN = (By.CLASS_NAME, 'checkout-buttons')
    COUNTRY_DROPDOWN = (By.XPATH, '//*[@id="BillingNewAddress_CountryId"]')
    STATE = (By.XPATH, '//*[@id="BillingNewAddress_StateProvinceId"]')
    CITY_TXT_BOX = (By.ID, 'BillingNewAddress_City')
    ADD_1_TXT_BOX = (By.ID, 'BillingNewAddress_Address1')
    ADD_2_TXT_BOX = (By.ID, 'BillingNewAddress_Address2')
    ZIP_CODE_TXT_BOX = (By.ID, 'BillingNewAddress_ZipPostalCode')
    CONTINUE_BTN = (By.ID, 'billing-buttons-container')
    CONTINUE_BTN_PAYMENT_METH = (By.XPATH, '//*[@id="shipping-buttons-container"]/input')
    CONTINUE_BTN_PAYMENT_INFO = (By.XPATH, '//*[@id="payment-info-buttons-container"]/input')
    CONTINUE_BTN_CONFIRM_ORDER = (By.CLASS_NAME, 'button-1 confirm-order-next-step-button')
    CONTINUE_THANK_YOU_PAGE = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/div/div[2]/div/div[3]/input')

class MainNavLocators(object):

    LOGOUT_LINK = (By.CLASS_NAME, 'ico-logout')
    NEW_PRODUCTS_LINK = (By.XPATH, '/html/body/div[9]/div[1]/div[2]/div/div[2]/div/ul/li[9]/a')

class FooterLocators(object):

    ABOUT_US = (By.XPATH, '/html/body/div[9]/div[6]/div[2]/div/div[1]/ul/li[1]/a')
    ABOUT_US_PAGE_HEADER = (By.XPATH, '//*[@id="ph-title"]/h1')
    PRIVACY_POLICY = (By.XPATH, '/html/body/div[9]/div[6]/div[2]/div/div[1]/ul/li[2]/a')
    PRIVACY_POLICY_HEADER = (By.XPATH, '//*[@id="ph-title"]/h1')
    CONDITIOS_OF_USE = (By.XPATH, '/html/body/div[9]/div[6]/div[2]/div/div[1]/ul/li[3]/a')
    CONDITIOS_OF_USE_HEADER = (By.XPATH, '//*[@id="ph-title"]/h1')
    FAQ_LINK = (By.XPATH, '/html/body/div[9]/div[6]/div[2]/div/div[2]/ul/li[1]/a')
    SHIPPING_RETURN = (By.XPATH, '/html/body/div[9]/div[6]/div[2]/div/div[2]/ul/li[4]/a')
    CONTACT_US_LINK = (By.XPATH, '/html/body/div[9]/div[1]/div[2]/div/div[2]/div/ul/li[11]/a')
    CONTACT_US_SUBMIT_BTN = (By.XPATH, '/html/body/div[9]/div[4]/div[5]/div/div/div[2]/form/div[2]/input')




