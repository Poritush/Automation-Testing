from tests.base import UIAutomationBase
from selenium.webdriver.common.keys import Keys
from pages.locators import AllCatagoriesMenu, BuyNowPage, CheckoutPageLocators
import time
from common.waits import DriverWaits


class TestBuyNowProduct(UIAutomationBase):

    def __init__(self, driver):
        self.driver = driver
        self.driver_waits = DriverWaits(self.driver)

    def buy_products(self, driver_waits):
        cotton_sharee_link = self.driver.find_element(*AllCatagoriesMenu.COTTON_SAREE).click()
        self.driver_waits.wait_till_element_is_visible(AllCatagoriesMenu.COTTON_SAREE_ATR_CLK)
        time.sleep(2)

        buy_now_cotton_saree = self.driver.find_element(*BuyNowPage.BUY_NOW_BTN).click()
        time.sleep(3)

    def popup_window(self):

        popup_buy_now_btn = self.driver.find_element(*BuyNowPage.GO_TO_CART_POPUP).click()
        popup_window = self.driver.switch_to.frame

        self.driver_waits.wait_till_element_is_visible(BuyNowPage.CONTINUE_SHOPPING_BTN)

    def continue_shopping(self):

        self.driver.find_element(*BuyNowPage.CONTINUE_SHOPPING_BTN).click()
        self.driver.find_element(*BuyNowPage.BUY_NOW_CONT_BTN).click()

        self.driver_waits.wait_till_element_is_visible(*BuyNowPage.GO_TO_CART_POPUP)

    def popup_shopping_continue(self):

        popup_continue = self.driver.find_element(*BuyNowPage.GO_TO_CART_POPUP).click()
        popup_continue_window = self.driver.switch_to.frame

        self.driver_waits.wait_till_element_is_visible(BuyNowPage.CONTINUE_SHOPPING_BTN)

        self.driver.find_element(*BuyNowPage.PROCEED_TO_CHECKOUT_BTN).click()
        time.sleep(3)

        self.driver.find_element(*BuyNowPage.CONTINUE_BTN_BILLING_ADDRESS_PAGE).click()
        time.sleep(3)

        self.driver.find_element(*BuyNowPage.CONTINUE__BTN_CHECKOUT_PAGE).click()
        time.sleep(3)

        self.driver.find_element(*BuyNowPage.CONTINUE_BTN_PAYMENT_INFO).click()
        time.sleep(3)

        self.driver.find_element(*BuyNowPage.CONTINUE_BTN_CONFIRM_ORDER_PAGE).click()
        time.sleep(3)

        self.driver.find_element(*CheckoutPageLocators.CONTINUE_BTN_CONFIRM_ORDER).click()

    def get_number_from_string(string):

        num = ''
        for itert in string:
            if itert in '1234567890':
                num+=itert

        integer = int(num)

        return integer

    price_1_text = 't3,850'
    quantity_1_text = '1'
    total_1_text = '3,850'
    price_1 = get_number_from_string(price_1_text)
    quantity_1 = get_number_from_string(quantity_1_text)
    total_1_number = get_number_from_string(total_1_text)

    total = 0
    for price in total:

        total = total + (price_1 * quantity_1)

    assert total == total_1_number































