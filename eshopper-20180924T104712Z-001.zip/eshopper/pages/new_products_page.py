from pages.locators import MainNavLocators, HomePageLocators
import time
from common.waits import DriverWaits

class NewProducts(object):

    def __init__(self, driver):
        self.driver = driver
        self.driver_waits = DriverWaits(self.driver)

    def new_products(self):
        self.driver.find_element(*MainNavLocators.NEW_PRODUCTS_LINK).click()

        time.sleep(3)

        try:
            self.driver_waits.wait_till_element_is_visible(HomePageLocators.LOGO)

        except TimeoutError:
            raise AssertionError('Element is not present')
