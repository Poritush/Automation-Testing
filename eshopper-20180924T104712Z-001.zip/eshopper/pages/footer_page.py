import time
from pages.locators import FooterLocators, HomePageLocators
from common.waits import DriverWaits

class FooterContent(object):

    def __init__(self, driver):
        self.driver = driver
        self.driver_waits = DriverWaits(self.driver)

    def about_us_page(self):
        page_about_us = self.driver.find_element(*FooterLocators.ABOUT_US).click()
        self.driver_waits.wait_till_element_is_visible(FooterLocators.ABOUT_US_PAGE_HEADER)

        assert "About Us" in page_about_us


    def privacy_policy(self):

        self.driver.find_element(*FooterLocators.PRIVACY_POLICY).click()

        time.sleep(3)
        self.driver_waits.wait_till_element_is_present(FooterLocators.PRIVACY_POLICY_HEADER)

    def conditions_of_use(self):

        self.driver.find_element(*FooterLocators.CONDITIOS_OF_USE).click()
        time.sleep(3)

        self.driver_waits.wait_till_element_is_visible(FooterLocators.CONDITIOS_OF_USE_HEADER)


    def contact_us(self):

        self.driver.find_element(*FooterLocators.CONTACT_US_LINK).click()
        time.sleep(3)

        self.driver_waits.wait_till_element_is_clickable(FooterLocators.CONTACT_US_SUBMIT_BTN)
        self.driver.find_element(*HomePageLocators.LOGO).click()

    def faq(self):

        self.driver.find_element(*FooterLocators.FAQ_LINK).click()
        time.sleep(3)

        self.driver.find_element(HomePageLocators.LOGO).click()






