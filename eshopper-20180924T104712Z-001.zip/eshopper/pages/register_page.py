import settings
from pages.locators import LoginPageLocators, RegisterPageLoc
from selenium.webdriver.support.select import Select
from common.waits import DriverWaits
import time

class RegisterPage(object):

    def __init__(self, driver):
        self.driver = driver
        self.driver_waits = DriverWaits(self.driver)

    def registerpage(self):

        self.driver.find_element(*RegisterPageLoc.MY_ACCOUNT_LINK).click()
        time.sleep(2)

        self.driver.find_element(*RegisterPageLoc.REGISTER_LINK).click()
        self.driver.find_element(*RegisterPageLoc.GENDER_CHECKBOX).click()
        self.driver.find_element(*RegisterPageLoc.FIRST_NAME_TXT_BOX).send_keys('Poritush')
        self.driver.find_element(*RegisterPageLoc.LAST_NAME_TXT_BOX).send_keys('Ghosh')
        self.driver.find_element(*RegisterPageLoc.EMAIL_TXT_BOX).send_keys('poritush_ict@yahoo.com')
        self.driver.find_element(*RegisterPageLoc.PHONE_TXT_BOX).send_keys('01734543485')
        self.driver.find_element(*RegisterPageLoc.PASSWORD_TXT_BOX).send_keys('ch@NDR@')
        self.driver.find_element(*RegisterPageLoc.CONFIRM_PASSWORD_TXT_BOX).send_keys('ch@NDR@')

    def test_select_from_dropdown_Select(self):
        select_dd = self.driver.find_element(*RegisterPageLoc.DOB_DD)
        select_date = Select(select_dd)
        select_date_obj = select_date.select_by_index(3)
        time.sleep(2)

        # select_dd_objs = select_date_obj.all_selected_options
        # assert len(select_dd_objs) == 1, 'Someting worong'
        # assert select_dd_objs[3].get_attribute('value') == '04', 'Wrong'

        select_mm = self.driver.find_element(*RegisterPageLoc.DOB_MM)
        select_month = Select(select_mm)
        select_mm = select_month.select_by_value('December')
        time.sleep(2)

        select_yr = self.driver.find_element(*RegisterPageLoc.DOB_YYYY)
        select_yyyy = Select(select_yr)
        select_yyyy.select_by_visible_text('1987')
        time.sleep(2)

        self.driver.find_element(*RegisterPageLoc.REGISTER_BTN).click()
        time.sleep(5)

        password = self.driver.find_element(*RegisterPageLoc.PASSWORD_TXT_BOX).send_keys('ch@NDR@')
        confirm_passw = self.driver.find_element(*RegisterPageLoc.CONFIRM_PASSWORD_TXT_BOX).send_keys('ch@NDR@')
        assert password == confirm_passw, 'Password is wrong'

        self.driver_waits.wait_till_element_is_visible(*RegisterPageLoc.REGISTER_CONFIRM)






