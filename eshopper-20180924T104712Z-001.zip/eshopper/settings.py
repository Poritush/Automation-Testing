BASE_URL = 'https://www.eshopper24.com/'
LOGIN_CREDENTIALS = {
    'email': 'poritush_ict@yahoo.com',
    'password': 'ch@NDR@',
}

course_id_price_map = {
    '56738': '$199',
    '56740': '$99',
    '144684': '',
    '154615': '$398',
    '94053': '$199',
}
