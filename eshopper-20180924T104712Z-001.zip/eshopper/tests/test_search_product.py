from tests.base import UIAutomationBase
from selenium.webdriver.common.keys import Keys
from pages.locators import HomePageLocators
from common.waits import DriverWaits
import random

class TestSearchCourse(UIAutomationBase):

   def __init__(self, driver):
      self.driver = driver
      self.driver_waits = DriverWaits(self.driver)

   def search_products_by_keyword(self, query_string=''):

       search_by_text = self.driver.find_element(*HomePageLocators.SEARCH_BOX)
       search_by_text.clear()
       search_product = search_by_text.send_key(query_string)
       click_search_btn = self.driver.find_element(*HomePageLocators.SEARCH_ICON).click()
       click_serach_btn_1 = self.driver.search_product.send_keys(Keys.RETURN)

       self.driver_waits.wait_till_element_is_visible(HomePageLocators.SEARCH_RESULT_TEXT)

       assert self.driver.find_element(*HomePageLocators.SEARCH_RESULT_TEXT).text == query_string, 'Search results is Wrong'








