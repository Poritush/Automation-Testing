import unittest  # built-in test framework in python

#  from nose.tools import nottest

from selenium import webdriver


class GetUrlTest(unittest.TestCase):  # TestCase is a base class for Test Suite
    target_url = 'https://letskodeit.teachable.com/p/practice'

    # @nottest

    def test_get_url(self):  # test case must have the substring 'test'
        """
        Validate correct URL is loaded
        :return:
        """

        driver = webdriver.Chrome()  # driver user defined variable

        driver.get(self.target_url)

        current_url = driver.current_url

        #  assert condition, , error_massage[optional] -> print erroe message if test fails

        assert 'google.com' in current_url, 'Expected: {}; Actual: {}'.format(self.target_url, current_url)

        driver.quit()

if __name__ == '__main__':
    unittest.main()
#
# test_instance = GetUrlTest()
# test_instance.test_get_url()

