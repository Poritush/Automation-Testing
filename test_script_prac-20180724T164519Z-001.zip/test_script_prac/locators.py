from selenium.webdriver.common.by import By


class Locators(object):
    # MAIN_PAGE_CSS_SELECTOR = (By.CSS_SELECTOR, '.view-school')
    # MAIN_PAGE_CSS = (By.CLASS_NAME, 'view-school')
    # MAIN_PAGE_XPATH = (By.XPATH, '//div[@class="view-school"]')
    #
    # RADIO_BUTTON_SECTION = (By.ID, 'radio-btn-example')
    # RADIO_BUTTON_OPTIONS = (By.CSS_SELECTOR, '#radio-btn-example input[name="cars"]')
    # # xpath = //div[@id="radio-btn-example"]//input[@name="cars"]

    # SELECT_SECTION = (By.ID, 'carselect')
    # SELECT_OPTIONS = (By.CSS_SELECTOR, '#carselect option')  # xpath: //'*[@id="carselect"]//option'
    #
    # INPUT_FOR_ALERT = (By.ID, 'name')
    # ALERT_BUTTON = (By.ID, 'alertbtn')

    LOGIN = (By.PARTIAL_LINK_TEXT, 'Login')
    USER_NAME = (By.ID, 'user_email')
    PASSWORD = (By.ID, 'user_password')
    SUBMIT = (By.XPATH, '//*[@id="new_user"]')
    FIRST_ELEMENT = (By.__class__, 'course-listing-title')
    FULL_BOX = (By.__class__, 'col-xs-12 col-sm-6 col-md-4')
    FIRST_ELEMENT_PRICE = (By.ID, 'course-box-price-product-342636')
    ICON_LOGOUT = (By.__class__, 'gravatar')
    LOGOUT = (By.PARTIAL_LINK_TEXT, 'Log Out')
    # CONFIRM_BUTTON = (By.ID, 'confirmbtn')
    #
    # MOUSE_HOVER_BUTTON = (By.ID, 'mousehover')
    # MOUSE_HOVER_MENU = (By.CLASS_NAME, 'mouse-hover-content')
    # MOUSE_HOVER_OPTIONS = (By.CSS_SELECTOR, '.mouse-hover-content a')  # xpath = //div[@class="mouse-hover-content"/a]

