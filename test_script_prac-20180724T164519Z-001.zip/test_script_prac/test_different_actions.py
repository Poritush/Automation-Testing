import unittest
import time
#
#  from nose.plugins.attrib import attr
from selenium import webdriver
#  from selenium.webdriver.support.select import Select
#  from selenium.webdriver.common.action_chains import ActionChains
#  from selenium.common.exceptions import TimeoutException
#
# from Python_Tutorials.test_script.locators import Locators
from test_script_prac.locators import Locators

#  from Python_Tutorials.test_scripts.waits import DriverWaits
from test_script_prac.waits import DriverWaits

from selenium.webdriver.common.by import By
#
#
class TestActions(unittest.TestCase):
    base_url = 'https://letskodeit.teachable.com/p/practice'


    # @classmethod  # decorator
    # def setUpClass(cls):

    #
    # def setUp(self):
    #     pass
    # def tearDown(self):
    #     pass
    #
    # @classmethod
    # def tearDownClass(cls):
    #     pass
    #
    # def do_something(self):
    #     pass
    #
    # def test_1(self):
    #     pass
    #
    # def test_2(self):
    #     pass

    @classmethod
    def setUpClass(cls):
        """
        This method runs at the very beginning of a test suite and runs for once
        :return:
        """
        cls.driver = webdriver.Chrome()
        cls.driver.maximize_window()
        cls.driver_waits = DriverWaits(cls.driver)

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def setUp(self):
        """
        This method runs before each test case
        :return:
        """
        self.driver.get(self.base_url)

        login_button = self.driver.find_element(*Locators.LOGIN).click()
        time.sleep(5)

        user_name = self.driver.find_element(*Locators.USER_NAME).send_keys('poritush_ict@yahoo.com')
        time.sleep(5)

        password = self.driver.find_element(*Locators.PASSWORD).send_keys('ch@NDR@')
        time.sleep(5)

        submit = self.driver.find_element(*Locators.SUBMIT).click()
        time.sleep(5)

    def test_search(self):
        search_selenium = self.driver.find_element(*Locators.FIRST_ELEMENT).get_attribute('Selenium')
        search_price = self.driver.find_element(*Locators.FULL_BOX).find_element(*Locators.FIRST_ELEMENT_PRICE).get_attribute('$199')
        icon = self.driver.find_element(*Locators.ICON_LOGOUT).click()
        logout = self.driver.find_element(*Locators.LOGOUT).click()




    # def test_current_url(self):
    #     """
    #     Test correct URL is loaded
    #     :return:
    #     """
    #     current_url = self.driver.current_url
    #
    #     error_msg = 'Current URL is wrong. Expected URL: {}; Actual URL: {}'.format(
    #         self.base_url, current_url
    #     )
    #     assert current_url == self.base_url, error_msg

    # def test_select_from_dropdown(self):
    #     """
    #     Select element by value with custom process
    #     :return:
    #     """
    #     select_element = self.driver.find_element(*Locators.SELECT_SECTION)
    #     select_element.click()
    #     select_options = self.driver.find_elements(*Locators.SELECT_OPTIONS)
    #
    #     value_to_select = 'benz'
    #
    #     for option in select_options:
    #         option_value = option.get_attribute('value')
    #         if option_value == value_to_select:
    #             option.click()
    #             break
    #
    #     selected_option = None
    #     for option in select_options:
    #         if option.get_attribute('selected') == 'true':
    #             selected_option = option
    #             break
    #
    #     assert selected_option is not None, 'No option selected'
    #     selected_value = selected_option.get_attribute('value')
    #     assert selected_value == value_to_select, 'Expected: {}; Actual: {}'.format(value_to_select, selected_value)

#     def test_select_from_dropdown_by_Select(self):
#         """
#         Select element by Select class
#         :return:
#         """
#         select_element = self.driver.find_element(*Locators.SELECT_SECTION)
# #
#         select_obj = Select(select_element)
# #
#         select_obj.select_by_value('honda')
#         # time.sleep(2)
#         #
#         # select_obj.select_by_index(1)
#         #
#         # time.sleep(2)
#         # select_obj.select_by_visible_text('BMW')
#         #
#         # time.sleep(2)
#         selected_option = select_obj.all_selected_options
#         assert len(selected_option) == 1, 'Something wrong'
#         selected_option = selected_option[0]
#
#         assert selected_option.get_attribute('value') == 'honda', 'Wrong option selected'
#
#     @attr('test')
#     def test_accept_alert_box(self):
#         text_input = self.driver.find_element(*Locators.INPUT_FOR_ALERT)
#         text_input.clear()
#
#         test_to_appear = 'Student'
#         text_input.send_keys(test_to_appear)
# #
#         self.driver.find_element(*Locators.ALERT_BUTTON).click()
# #
#
#         try:
#             self.driver_waits.wait_till_alert_is_present()
#         except TimeoutException:
#             raise AssertionError('Alert is not present')
# #
#         alert_window = self.driver.switch_to.alert
#         alert_text = alert_window.text
# #
#         assert 'Student' in alert_text, 'Expected text is missing there'
# #
#         alert_window.accept()
# #
#         try:
#             self.driver_waits.wait_till_alert_is_dismissed()
#         except TimeoutException:
#             raise AssertionError('Alert did not dismiss')
#
#     @attr('only')
#     def test_mouse_hover(self):
#         # self.driver.execute_script("window.scrollBy(0, 800);")
#
#         action_chains = ActionChains(self.driver)
#
#         import pdb; pdb.set_trace()
#         action_chains.move_by_offset(0, 800)
#
#         mouse_hover_menu = self.driver.find_element(*Locators.MOUSE_HOVER_MENU)
#
#         assert not mouse_hover_menu.is_displayed(), 'Mouse hover menu is displayed'
#
#         mouse_hover_button = self.driver.find_element(*Locators.MOUSE_HOVER_BUTTON)
#
#         # action_chains = ActionChains(self.driver)
#         action_chains.move_to_element(mouse_hover_button)
#         action_chains.perform()
#
#         time.sleep(5)
#
#         assert mouse_hover_menu.is_displayed(), 'Mouse hover menu is not displayed'
#
#
if __name__ == '__main__':
    unittest.main()

#
#
#
#
